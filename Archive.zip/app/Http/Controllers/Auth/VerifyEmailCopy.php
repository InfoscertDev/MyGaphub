<?php

namespace Illuminate\Auth\Notifications;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Lang;
use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class VerifyEmail extends Notification
{
    /**
     * The callback that should be used to build the mail message.
     *
     * @var \Closure|null
     */
    public static $toMailCallback;

    /**
     * Get the notification's channels.
     *
     * @param  mixed  $notifiable
     * @return array|string
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Build the mail representation of the notification.
     *
     * @param  mixed  $notifiable 
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        if (static::$toMailCallback) {
            return call_user_func(static::$toMailCallback, $notifiable);
        } 
        $action =  $this->verificationUrl($notifiable);
        return (new MailMessage) 
             ->subject(Lang::getFromJson('Welcome to GAPhub'))
             ->markdown('vendor.notifications.email', compact('notifiable', 'action'));
            // ->line(Lang::getFromJson('Hi ' . $notifiable->firstname . ','))
            // ->line(Lang::getFromJson('Welcome to GAPhub! Your GAPhub account ID is '. $notifiable->email.'. We are always delighted to have a new member join this family of people who are committed to financial independence and working on having the freedom and time to pursue their passion. GAPhub offers you a variety of tools and opportunities to help you take control of your financial life. You can access all aspects of your financial life from our easy-to-use and friendly interface.'))
            // ->subject(Lang::getFromJson('Verify Email Address'))
            // ->line(Lang::getFromJson('Please click the button below to verify your email address.'))
            // ->action(
            //     Lang::getFromJson('Verify Email Address'),
            //     $this->verificationUrl($notifiable)
            // )
            // ->line(Lang::getFromJson('If you did not create an account, no further action is required.') )
           ;
    }

    
    /**
     * Get the verification URL for the given notifiable.
     *
     * @param  mixed  $notifiable
     * @return string
     */
    protected function verificationUrl($notifiable)
    {
        return URL::temporarySignedRoute(
            'verification.verify', Carbon::now()->addMinutes(60), ['id' => $notifiable->getKey()]
        );
    }

    /**
     * Set a callback that should be used when building the notification mail message.
     *
     * @param  \Closure  $callback
     * @return void
     */
    public static function toMailUsing($callback)
    {
        static::$toMailCallback = $callback;
    }
}
