<li class="listing col span_4 standard">
    <figure>
        <h6 class="snipe featured for-sale " style="display: block;"><span style=" background: #ff0000 !important;"> REAP UK </span></h6> 
        
        <ul class="listing-actions">
            
        </ul>
        <a href="https://gappropertyhub.com/assets/149"><img src="https://gappropertyhub.com/storage/asset_images/33b532c7216c0bab8c1a9336f286174eb219ffae638711.jpg" class="attachment-listings-featured-image size-listings-featured-image" alt=""></a>
    </figure>
    <div class="grid-listing-info">
        <header>
            <h5 class="marB0"><a href="https://gappropertyhub.com/assets/149">3 Bed at Joseph Levy Walk</a></h5>
            <p class="location muted marB0">United Kingdom, Coventry,Joseph Levy Walk </p>
        </header>
        <p class="price marB0"><span class="listing-price">£ 315,000</span></p>
        <div class="propinfo">
            <p>THREE BEDROOM DETACHED property in the Binley area. The property briefly comprises of...</p>
            <ul class="marB0">
                <li class="row beds"><span class="muted left">Bed</span><span class="right">3</span></li>
                <li class="row baths"><span class="muted left">Baths</span><span class="right">2</span></li>
                <li class="row sqft"><span class="muted left"> Monthly Income</span><span class="right">£1,080</span></li>
            </ul>
        </div>
        
        <div class="brokerage">
            <p class="muted marB0"><small></small></p> 
            <p class="marB0"><a href="https://gappropertyhub.com/search?ct_property_type=REAP UK&amp;search-listings=true">view all</a></p>
        </div>
        
    </div>    
</li>