@extends('layouts.user')
@section('content')
    <style>
    </style>
    <div class="wd-f bg-white py-3">
        <div class="modal fade" id="subscribeModal" tabindex="-1" role="dialog" aria-labelledby="subscribeModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content wd-c"> 
                    <div class="modal-body">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <div class="">
                            <div class="card-img px-5 wd-8 mx-auto text-center sm-wdf sm-no-pad">
                                <img src="{{ url('http://prismcheck.com/releasea/ganp/public/'. str_replace('public', 'storage', $plant->image3 )) }}" alt=" " style="height: 300px" class="wd-f py-3 px-2 mb-3">
                                <h2 class="display bold">{{ $plant->name }}</h2>
                                <p> {{$plant->rate}}% Return • {{$plant->months}} Months</p> 
                                <h5> Your Subscriptions Amount </h5> 
                                <h4 class="bold"> {{explode(' ', $plant->currency)[0] }}<span id="tamount"></span>  </h4>
                                <h5 class="bold"> (Actual Fixed Price: ) </h5>
                                {{-- N750,000 --}} 
                                <div class="bg-gray row my-2 p-3">
                                    <p class=""> Representative Example (Variable): In the {{$plant->months / $plant->max_pay}}th month you will receive {{explode(' ', $plant->currency)[0] }}<span id="profit_pay"></span>
                                        (<span id="per_pay"></span>% of your returns)
                                        @if ($plant->max_pay > 1) 
                                            and by the {{$plant->months}}th month, you will receive the balance of {{explode(' ', $plant->currency)[0] }}<span id="profit_pay"></span> 
                                        @endif
                                    </p>
                                    <p>As well as your capital of {{explode(' ', $plant->currency)[0] }}<span id="tamount"></span>. Total amount returned wiil be {{explode(' ', $plant->currency)[0] }}<span id="return"></span> </p>
                                </div>
                                <div class="text-left">
                                    <h6 class="bold">Disclaimer:</h6>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit ut blanditiis excepturi necessitatibus nobis molestias nostrum eius porro ipsum culpa!</p>
                                    <p>
                                        <input type="checkbox" name="confirm" class="form-control mr-2" style="height: 20px;display: inline;width: 20px;" id="">
                                            I agree with all the terms & conditions.
                                    </p>
                                </div> 

                                <p class="mt-2 text-right">
                                    <a href="#" class="mr-3">Local currecy equivalent</a>
                                        <button type="button" class="btn btn-pry btn-sm py-2 px-4" data-toggle="modal" data-target="#subscribeModal">Proceed To Provider Platform</button>
                                </p>
                            </div>
                        </div>
                    </div>
                </div> 
            </div> 
        </div>

        <div class="row mx-5">
            <span class="mr-3 pb-2" id="goback">
                <a href="#" class="text-dark bold" onclick="window.history.go(-1); return false;" ><i class="fa fa-chevron-left mr-1"></i> Back</a>
            </span>
            {{-- <div class="b-rad-20 mt-1 cal-head hd-ganp" id="authhead" style="height: 90px !important">
                <div class="b-rad-20 overlay2" style="height: 90px !important">
                    <div class="disclaim text-center">
                        <h2 class="list-explore" style="top: -15px;position: relative;" >Green Asset National Product (GANP)</h2> 
                    </div>
                </div>
            </div> --}}
        </div>

        {{-- <div class="row my-0 wd-8 mx-auto">
            <div class="my-4 b-rad-20 mt-1 cal-head hd-country mx-3" style="height: 85px !important;border-radius: 35px !important;
                        background: url({{  url('http://prismcheck.com/releasea/ganp/public/'. str_replace('public', 'storage', $gcountry->image)) }}) no-repeat; " id="authhead">
                <div class="b-rad-20 overlay2" style="height: 65px !important;top: 4px;position: relative;margin: auto 8px;">
                    <div class="disclaim text-center">
                        <h2 class="list-explore" style=" top: -15px; position: relative;">GANP  
                            @if ($gcountry->name) <span>{{$gcountry->name}}</span> @endif
                        </h2> 
                    </div>
                </div>
            </div>
        </div>  --}}


        <div class="row mt-3 ">
            <div class="col-12">
                <div class="reap-asset elevation-3">
                    <div class="row">
                        <div class="col-md-4 col-xs-12">
                            <div class="card-img">
                                <img src="{{ url('http://prismcheck.com/releasea/ganp/public/'. str_replace('public', 'storage', $plant->image2 )) }}" alt=" " style="height: 300px" class="wd-f py-3 px-2">
                            </div>
                        </div>
                        <div class="col-md-8 col-xs-12">
                            <div class="card-body">
                               <div class="row">
                                   <div class="col-12 mb-2">
                                       <h1 class="display sm-fs-18 sm-bold">{{ $plant->name }} Illustration and Intelligence Report</h1>
                                       <div class="wd-7 mb-2"> 
                                           <input type="hidden" name="amount" id="amount" value="{{$plant->amount}}">
                                           <input type="hidden" name="months" id="months" value="{{$plant->months}}">
                                           <input type="hidden" name="rate" id="rate" value="{{$plant->rate}}">
                                           <input type="hidden" name="pay" id="pay" value="{{$plant->max_pay}}">
                                            <select name="units" id="units" class="form-control wd-7" onchange="chooseUnit()">
                                                <option value="1">Select your subscription units</option>
                                                <option value="5">5</option>
                                                <option value="10">10</option>
                                                <option value="15">15</option><option value="20">20</option>
                                                <option value="25">25</option>
                                                <option value="30">30</option> <option value="35">35</option>
                                                <option value="40">40</option>
                                                <option value="50">50</option>
                                                <option value="150">150</option>
                                                <option value="200">200</option>
                                                <option value="250">250</option>
                                                <option value="300">300</option>
                                                <option value="500">500</option>
                                                <option value="750">750</option>
                                                <option value="1000">1000</option>
                                            </select>
                                       </div>
                                   </div>
                                   <div class="col">
                                       <div class="text-cult mb-3">
                                           <h6 class="bold">Subscription Units</h6>
                                           <h4 id="subunit"></h4>
                                       </div>
                                       <div class="text-cult mb-3">
                                           <h6 class="bold">Returns</h6>
                                           <h4 class="sm-fs-16">{{explode(' ', $plant->currency)[0] }} <span id="return"></span>
                                            {{-- {{ number_format((($plant->amount * $plant->rate) / 100) + $plant->amount, 2) }} --}}
                                        </h4>
                                       </div>
                                       <div class="text-cult mb-3">
                                           <h6 class="bold">Payment Frequency</h6>
                                           <h4 class="sm-fs-16">{{ $plant->max_pay }}</h4>
                                       </div>
                                       <button type="button" class="btn btn-pry btn-sm py-2 px-4" data-toggle="modal" data-target="#subscribeModal">Subscribe</button>
                                   </div>
                                   <div class="col">
                                       <div class="text-cult mb-3">
                                           <h6 class="bold">Amount</h6>
                                           <h4 class="sm-fs-16"> {{explode(' ', $plant->currency)[0] }} <span id="tamount"></span> </h4>
                                       </div>
                                       <div class="text-cult mb-3">
                                           <h6 class="bold">Total Profits</h6>
                                           <h4 class="sm-fs-16">  {{explode(' ', $plant->currency)[0] }}<span id="profit"></span>
                                            {{-- {{  number_format(($plant->amount * $plant->rate) / 100, 2) }}  --}}
                                         </h4>
                                       </div>
                                       <div class="text-cult mb-3">
                                           <h6 class="bold">Equivalent Monthly Profit</h6>
                                           <h4 class="sm-fs-16">  {{explode(' ', $plant->currency)[0] }}<span id="month_profit"></span>  </h4>
                                       </div>
                                   </div>
                                   {{-- <div class="col d-none d-md-block"></div> --}}
                                   <div class="col goffset-sm-6"> 
                                       <div class="text-cult sm-mt1 mb-3 sm-mr-8"> 
                                           <h6 class="bold">Term</h6>
                                           <h4 class="sm-fs-16">{{ $plant->months }} Months</h4>
                                       </div>
                                       <div class="text-cult mb-3">
                                           <h6 class="bold">Rate</h6>
                                           <h4 class="sm-fs-16">{{ $plant->rate }}%</h4>
                                       </div>
                                   </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-12  my-3">
                    <div class=" m-5">
                        <h4 for="" class="text-center">Units Remaining: {{ number_format($plant->total_units) }} </h4>
                        {{-- <input type="range" min="1" max="100" value="1" class="slider form-control" id="unitRange">  --}}
                        <div class="range mt-3">
                            <input type="range" min="1" class="wd-f" max="{{$plant->total_units}}" disabled value="{{$plant->total_units}}">
                        </div>
                      </div>
                </div>

                <div class="col-12 ">
                    <div id="accordion">
                        <div class="card">
                            <div class="accord-header bg-dark mb-0 py-2" id="headingOne">
                                <div class="wd-f">
                                    <a href="#" class="text-white"  data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">Summary</a>
                                    <button class="btn btn-accord" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        <i class="fa fa-chevron-down text-white"></i>
                                    </button> 
                                </div>
                            </div>
                        
                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                <div class="card-body pb-1">
                                    <div class="card-body pb-1">
                                        <p> {{ $plant->summary }}  </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card my-3">
                            <div class="accord-header bg-dark mb-0 py-2" id="headingTwo">
                                <div class="wd-f">
                                    <a href="#" class="text-white"  data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">Intelligence Report</a>
                                    <button class="btn btn-accord" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                        <i class="fa fa-chevron-down text-white"></i>
                                    </button> 
                                </div>
                            </div>
                        
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                <div class="card-body pb-1">
                                    <div class="card-body pb-1">
                                        @if ($plant->report)
                                            <p> {{ $plant->report }}  </p>
                                        @else
                                            <p>Available On Request </p>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- <div class="card mt-5 mb-3">
                        <div class="card-header bg-dark">
                            <div class="card-title"> <h4 class=" pl-5 text-white">Summary</h4></div>
                        </div>
                        <div class="card-body bg-gray">
                            <p>{{ $plant->summary }}</p>
                            <div class=" text-right my-3">
                                <button type="button" class="btn btn-dark btn-sm py-2 px-4">Intelligence Report</button>
                                <button type="button" class="btn btn-pry btn-sm py-2 px-4" data-toggle="modal" data-target="#subscribeModal">Subscribe</button>
                            </div>
                        </div>
                    </div> --}}
                </div>
                
                <div class="mx-auto text-center my-3">
                    <button type="button" class="btn btn-pry btn-sm py-2 btn-block-sm" data-toggle="modal" data-target="#subscribeModal">Subscribe</button>
                </div>
            </div>  
            

        </div>
    </div> 

<script>

    function chooseUnit(){
        let units = document.getElementById('units').value,
            months = document.getElementById('months').value,
            rate =  document.getElementById('rate').value,
            pay = document.getElementById('pay').value,
            amount = document.getElementById('amount').value;

        let subunit = document.querySelectorAll('#subunit'),
            tamount = document.querySelectorAll('#tamount'),
            profit = document.querySelectorAll('#profit'),
            month = document.querySelectorAll('#month_profit'),
            returns = document.querySelectorAll('#return');
   
        let profit_pay = document.querySelectorAll('#profit_pay'),
            per_pay = document.querySelectorAll('#per_pay'); 

        var pro = (+units * +amount  * +rate) / 100 ;


        subunit.forEach((sub) => {
            sub.textContent = (+units) ;
        })

        tamount.forEach((pr) => {
            pr.textContent = (units * amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); ;
        }); 
        
        // returns.textContent = (pro + +units * +amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); ;
        returns.forEach((pr) => {
            pr.textContent = (pro + +units * +amount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); ;
        })

        // month.textContent = ((pro) / months ).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); ; 
        month.forEach((pr) => {
            pr.textContent = ((pro) / months ).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); ;
        })

        profit.forEach((pr) => { 
            pr.textContent = pro.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); ;
        })

        profit_pay.forEach((pr) => { 
            pr.textContent = (pro / pay).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); ;
        })

        per_pay.forEach((pr) => {  
            pr.textContent = (100 / pay).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); ;
        })
    }

    function refreshReport() {
        chooseUnit();
    }


    refreshReport();
</script>
@endsection 