@extends('layouts.user')

@section('header')
{{-- <link rel="stylesheet" href="https://gappropertyhub.com/css/styles.css"> --}}
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://gappropertyhub.com/css/jquery-ui.min.css">
    <link rel="stylesheet" href="https://gappropertyhub.com/css/app.css">
    <link href="{{ asset('assets/css/gap.css') }}" rel="stylesheet">
    <!-- Styles -->
    <link rel="stylesheet" href="https://gappropertyhub.com/css/lightbox.min.css">
    <link rel="stylesheet" href="https://gappropertyhub.com/css/flexslider.css">
    <link rel="stylesheet" href="https://gappropertyhub.com/css/flexslider-direction-nav.css">
@endsection

@section('content')
    <div class="wd-f bg-white py-3"> 
        <div>  
            <span class="mr-3 pb-2" id="goback">
                <a href="#" class="text-dark" onclick="window.history.go(-1); return false;" ><i class="fa fa-chevron-left mr-1"></i> Back</a>
            </span>
        </div>
        {{-- @include('inc.reap-banner') --}}
        <div class="my-5">
            
            <div class="single-listings row mx-0">
                <article class="ml-3 md-no-ml span_9 marB60">
                    @if($asset->authorize == 0)
                        <div class="jumbotron full">
                            <p class="text-center"> This asset is under review by GAP Administrator and cannot be reserved yet.</p>
                        </div>
                    @elseif($asset->acquired_id > 0)
                        <div class="jumbotron full">
                            <p class="text-center"> This asset cannot be reserved.</p>
                        </div>
                    @else
                            <!-- Location --> 
                            <header class="listing-location mt-3">
                                    @if($asset->category != '')
                                        <div class="snipe-wrap">
                                        <h5 class="snipe" style="display: block;">
                                                <span style="background:   {{$asset->category->region}} !important;">{{ $asset->category->name }}</span></h5>
                                        <div class="clear"></div>
                                    </div>
                                    @endif
                
                                <h1 id="listing-title" class="marT24 marB0"> {{$asset->name}}</h1>
                                <p class="location marB0"><i class="country">{{ $asset->location->country }}, </i>  <i class="state">{{ $asset->location->city }}, </i>{{ $asset->location->street }}</p>
                            </header>
                            <!-- //Location -->
                            
                            <!-- Price -->
                            <h4 class="price marT0 marB0"><span class="listing-price-prefix"><!-- From --> </span><span class="listing-price"> {{$asset->currency}}{{ number_format($asset->investment->sale_price,2) }}</span><span class="listing-price-postfix"> <!-- /mo --></span></h4>
                            <!-- //Price -->
                            
                            <!-- Listing Info -->
                                <ul class="propinfo marB0">
                                    <li class="row beds"><span class="muted left">Bed</span><span class="right">{{ $asset->special_feature->spec_feature2 }}</span></li>
                                    <li class="row baths"><span class="muted left">Bath</span><span class="right">{{ $asset->special_feature->spec_feature3 }}</span></li>
                                    <li class="row baths"><span class="muted left">Rental Income</span><span class="right"> {{$asset->currency}}{{ $asset->investment->total_deduction }}</span></li>
                                    <li class="row sqft"><span class="muted left"> Sq Ft</span><span class="right">{{ $asset->special_feature->spec_feature4 }} 
                                        @if($asset->special_feature->spec_feature5)  
                                            -   {{$asset->special_feature->spec_feature5}}
                                        @endif</span>
                                    </li>
                                    {{-- <li class="row property-type"><span class="muted left">Property Type</span><span class="right">----</span></li> --}}
                                </ul>
                            <!-- //Listing Info -->
                
                            @include('inc.asset-gallery')
                
                            <div class="clear"></div>
                            <section id="asset">
                                <div class="panel-group" id="accordion">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                                            Property Description </a>
                                        </h4>
                                        </div>
                                            <div id="collapse1" class="panel-collapse collapse show">
                                            <div class="panel-body">
                                                {{-- {{ html_entity_decode($asset->description) }} --}}
                                                {!! nl2br($asset->description) !!}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Investment Numbers</a>
                                        </h4>
                                        </div>
                                        <div id="collapse2" class="panel-collapse collapse">
                                        <div class="panel-body">
                                            <table class="table table-bordered table-striped">
                                                <tfoot>
                                                <tr>
                                                    <th> <b>Rental Income:</b>   {{$asset->currency}}{{ $asset->investment->total_deduction }}
                                                        </th>
                                                    <th>
                                                        <b>Total Deductions:</b>   {{$asset->currency}}
                                                        {{-- {{ $deduct }}  --}}
                                                    </th>
                                                </tr>
                                                </tfoot>
                                                <tbody>
                                                <tr>
                                                    <td> <b>Sale Price:</b>  {{$asset->currency}}{{ number_format($asset->investment->sale_price,2) }}</td>
                                                    <td> <b>Management Fee:</b>{{$asset->currency}}{{ number_format($asset->investment->management_fee,2)}} </td>
                                                </tr>
                                                <tr>
                                                    <td><b>Rental Value:</b> {{$asset->currency}}{{ number_format($asset->investment->rental_price,2) }} </td>
                                                    <td> <b>Property Tax</b> {{$asset->currency}}{{ number_format($asset->investment->tax,2) }}</td>
                                                </tr> 
                                                <tr>
                                                    <td> <b>Gross ROI: </b> {{ $asset->investment->gross }} <b>%</b></td>
                                                    <td> <b>Misc & Assoc. Fee</b>  {{$asset->currency}}{{ number_format($asset->investment->associate_fee,2) }}</td>
                                                </tr>
                                                <tr>
                                                    <td><b>Net Revenue </b>  {{$asset->currency}}{{number_format($asset->investment->net_revenue,2) }}</td>
                                                    <td></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Special Features </a>
                                        </h4>
                                        </div>
                                        <div id="collapse3" class="panel-collapse collapse">
                                        <div class="panel-body">
                                            @foreach($specials as $feature)
                                                @if($feature != '' || $feature != null)
                                                    @if($loop->iteration == 1) <p class="list-group-item">Property Type: {{ $feature }}  
                                                    @elseif($loop->iteration == 2) <p class="list-group-item">Bed : {{ $feature }}  
                                                    @elseif($loop->iteration == 3 ) <p class="list-group-item">Bath : {{ $feature }}  
                                                    @elseif($loop->iteration == 4) <p class="list-group-item">Square Feet: {{ $feature }} 
                                                        @elseif($loop->iteration == 5) - {{ $feature }} 
                                                    @else
                                                        <p class="list-group-item">{{ $feature }}</p>
                                                        {{-- @if($loop->iteration !== 1 || $loop->iteration != 2 || $loop->iteration != 3 || $loop->iteration != 4 || $loop->iteration != 5)
                                                            <p class="list-group-item">{{ $feature }}</p> @endif --}}
                                                    @endif
                                                @endif
                                            @endforeach
                                        </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">
                                            Fact & Features</a>
                                            </h4>
                                        </div>
                                        <div id="collapse4" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                @if(count($features1) && count($features2))
                                                <span class="col-xs-6">
                                                    <ul class="list-group">
                                                        @foreach($features1 as $feature)
                                                            @if($feature != '' || $feature != null)
                                                                <li class="list-group-item xs-set">  {{ $feature }} </li> 
                                                                {{-- <i class="fa fa-check-square bg-lgrn"></i><i class="fa fa-check-square bg-lgrn"></i>--}}
                                                            @endif
                                                        @endforeach
                                                    </ul>
                                                </span>
                                                <span class="col-xs-6">
                                                    <ul class="list-group">
                                                            @foreach($features2 as $feature)
                                                                @if($feature != '' || $feature != null)
                                                                    <li class="list-group-item xs-set"> {{ $feature }} </li>
                                                                @endif
                                                            @endforeach
                                                    </ul>
                                                </span>
                                                @else
                                                    <p> None </p>
                                                @endif
                
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">Neighbourhood Highlights</a>
                                            </h4>
                                        </div>
                                        <div id="collapse5" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                @if($asset->neighborhood == '')
                                                    <p>None</p>
                                                @else
                                                {!! nl2br($asset->neighborhood) !!}  
                                                @endif
                                            </div>
                                        </div> 
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse6">
                                                Intelligent Report</a>
                                            </h4>
                                        </div>
                                        <div id="collapse6" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                @if($asset->inteligent_report  == '')
                                                    <p>None</p>
                                                @else  
                                                    {!! nl2br($asset->inteligent_report) !!}
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>  
                                <br>
                            </section>
                    @endif
                </article> 
                 
                <div class="ml-3 span_3">
                    @if (count($related))                        
                        <div class="card">
                            <div class="card-heading "><h4 class="card-title text-center"><b>Related Asset</b> </h4></div>
                            <ul class="list-group">
                                @foreach ($related as $asset)
                                    @if ($asset->id != $id) 
                                        <li class="list-group-item">
                                            <h4> <a href="{{ route('user.single_reap',$asset->id,['rs' => $asset->name]) }}">{{ $asset->name }}</a></h4> 
                                            <span><i class="country">{{ $asset->location->country }}, </i>  <i class="state">{{ $asset->location->city }}, </i>{{ $asset->location->street }}</span>
                                        </li>
                                    @endif
                                @endforeach
                            </ul>
                        </div> <br>
                    @endif
        
                    <div class="clear"></div>
            
                    <ul class=" p-0">
                        @foreach ($promotion as $asseted)
                        {{-- {{$asseted->promote->id}} --}}
                            @if($asseted->promote && $asseted->promote->id != $id)
                                <li class="listing" style="opacity: .88 :hover{ opacity: 1}">
                                    <figure> 
                                        @if($asseted->promote->category) <h6 class="snipe featured for-sale " style="display: block;"><span style=" background:  {{$asseted->promote->category->region}} !important;">  {{$asseted->promote->category->name}} </span></h6> @endif 
                                        <ul class="listing-actions">
                                                
                                        </ul> 
                                        <a href="{{ route('user.single_reap',[$asset->id,'rs' => $asset->name]) }}"><img src="{{url('https://gappropertyhub.com/storage/asset_images/' .$asseted->promote->asset_image->image1 ) }}" class="attachment-listings-featured-image size-listings-featured-image" alt=""></a>
                                    </figure>
                                    <div class="grid-listing-info">
                                        <header>
                                            <h5 class="marB0"><a href="{{ route('user.single_reap',[$asset->id,'rs' => $asset->name]) }}">{{ str_limit($asseted->promote->name, $limit = 35, $end = '...') }}</a></h5>
                                            <p class="location muted marB0">{{ $asseted->promote->location->country }}, {{ $asseted->promote->location->city }}, {{ $asseted->promote->location->street }}</p>
                                        </header>
                                        <p class="price marB0"><span class="listing-price"> {{$asseted->promote->currency}} {{ $asseted->promote->investment->sale_price }}</span></p>
                                        <div class="propinfo">
                                            <p>{{ str_limit($asseted->promote->description, $limit = 55, $end = '...') }}</p>
                                            <ul class="marB0 p-0">
                                                <li class="row beds"><span class="muted left">Bed</span><span class="right">{{ $asseted->promote->special_feature->spec_feature2 }}</span></li>
                                                <li class="row baths"><span class="muted left">Baths</span><span class="right">{{ $asseted->promote->special_feature->spec_feature3 }}</span></li>
                                                <li class="row sqft"><span class="muted left"> Rental Income</span><span class="right">{{$asseted->promote->currency}} {{ $asseted->promote->investment->total_deduction }}</span></li>
                                            </ul>
                                        </div>
                                    </div>      
                                </li>
                            @endif
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div> 
@endsection 

@section('script')
<script src="https://gappropertyhub.com/js/jquery.js"></script>
{{-- <script src="https://gappropertyhub.com/js/app.js"></script> --}}
<script src="https://gappropertyhub.com/js/jquery-ui.min.js"></script>
<script src="https://gappropertyhub.com/js/lightbox.min.js"></script>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
 <script src="https://gappropertyhub.com/js/jquery.flexslider-min.js?ver=5.0.1"></script>


<script type="text/javascript" charset="utf-8">
    $(window).load(function() {
         cnosle.log("Load");
        $('.flexslider').flexslider();
    });
</script>
<script type="text/javascript">
    
    // Slider     
    jQuery('#carousel').flexslider({
        animation: "slide",
        controlNav: false,
        animateHeight: true, 
        directionNav: true,
        animationLoop: false,
        slideshow: "true",
        slideshowSpeed: 7000,
        animationDuration: 600,
        itemWidth: 120,
        itemMargin: 0,
        asNavFor: '#slider'
    });

    jQuery('#slider').flexslider({
        animation: "fade",
        slideDirection: "horizontal",
        slideshow: "true",
        slideshowSpeed: 7000,
        animationDuration: 600,
        smoothHeight: true,
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        sync: "#carousel"
    });

    function popup(pageURL,title,w,h) {
        var left = (screen.width/2)-(w/2);
        var top = (screen.height/2)-(h/2);
        var targetWin = window.open (pageURL, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width='+w+', height='+h+', top='+top+', left='+left);
    }
</script> 
@endsection