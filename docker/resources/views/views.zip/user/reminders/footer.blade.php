<footer class="my-3 text-center">
    <p class="sm-fs-12">Financial Impact Reminder is a great way to make sure you never face embarrassment again
        or lose out financially through penalties.</p>
</footer>