@extends('layouts.user')
@section('content')
    <div class="container-fluid">
        <div class="pt-3">
          <div class="gap-center">
          </div>
        </div>
    </div>
@endsection