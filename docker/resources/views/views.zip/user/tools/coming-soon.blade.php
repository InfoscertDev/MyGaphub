@extends('layouts.user')
@section('content')

@include('inc.settings_menu')
<div class="">
    <div class="jumbotron text-center " style="vertical-align: middle; height: 300px">
       <h1 class="pt-5">Coming Soon</h1> 
   </div>
 </div>
@endsection