@extends('layouts.user')
@section('content')
    <div class="container-fluid">
        <div class="pt-3">
          <div class="gap-center">
           
            <div id='gcw_mainFgRPfyWNF' class='gcw_mainFgRPfyWNF'></div>
            <a id='gcw_siteFgRPfyWNF' href='https://freecurrencyrates.com/en/'>FreeCurrencyRates.com</a>
            <script>function reloadFgRPfyWNF(){ var sc = document.getElementById('scFgRPfyWNF');if (sc) sc.parentNode.removeChild(sc);sc = document.createElement('script');sc.type = 'text/javascript';sc.charset = 'UTF-8';sc.async = true;sc.id='scFgRPfyWNF';sc.src = 'https://freecurrencyrates.com/en/widget-table?iso=USD-EUR-GBP-RUB&df=2&p=FgRPfyWNF&v=fi&source=fcr&width=600&width_title=0&firstrowvalue=1&thm=A6C9E2,FCFDFD,4297D7,5C9CCC,FFFFFF,C5DBEC,FCFDFD,2E6E9E,000000&title=Currency%20Converter&tzo=-60';var div = document.getElementById('gcw_mainFgRPfyWNF');div.parentNode.insertBefore(sc, div);} reloadFgRPfyWNF(); </script>
            <!-- put custom styles here: .gcw_mainFgRPfyWNF{}, .gcw_headerFgRPfyWNF{}, .gcw_ratesFgRPfyWNF{}, .gcw_sourceFgRPfyWNF{} -->

          </div>
        </div>
    </div>
@endsection