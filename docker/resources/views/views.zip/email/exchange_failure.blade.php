@extends('email.layout')

@section('email_body')
    <div> 
         <p>Hello</p>
         <p>The recent Exchange Rate call failed. You can reset the timer call on Cron  Job configurstion   </p>
         {{-- <p>If this persist,  </p> --}}
         <p></p>
    </div>
@endsection 