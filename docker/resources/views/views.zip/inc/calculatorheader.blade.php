<div class="wd-f cal-head">
    <div class="overlay">
        <div class="head-pain">
            <div class="mb-4">
                <h4 class="">This is where the Experience</h4>    
                <h4 class=" txt-primary">Begins!</h4>
            </div>
            <p class="">
                Being financially independent is your ability to sustain your livelihood or lifestyle without relying on income from employment or self-employment (e.g. wages from jobs).    
            </p>    
        </div>
    </div>
</div>