<div class="wd-f cal-head hd-auth" id="authhead">
    <div class="overlay2" style="height: 230px;">
        <div class="head-pain text-center mt-5">
            {{-- <h2 class="txt-primary bold"><b>REGISTRATION</b> </h2>     --}}
            <h3 class=" ">We're excited you have decided to open a
                GAP Account!</h3>   
        </div>
    </div>
</div>