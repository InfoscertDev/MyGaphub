@extends('layouts.admin')
@section('content')
<div class="wrap">
     <div class="cs-wrap">
        <h1>Coming Soon</h1>
    </div>
  </div>
@endsection