@extends('layouts.admin')

@section('content')
    <div class="wd-f my-5">
        <div class="card">
            <div class="card-header">
                <h4>Admin</h4>
            </div> 
            <div class="card-body">
              {{-- <table class="table table-striped">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">First</th>
                    <th scope="col">Last</th>
                    <th scope="col">Handle</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                    <td>Mark</td>
                    <td>Otto</td>
                    <td>@mdo</td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td>Larry</td>
                    <td>the Bird</td>
                    <td>@twitter</td>
                  </tr>
                </tbody>
              </table> --}}
              <div class="jumbotron text-center">
                <h4>No Admin Yet</h4>
              </div>
            </div>
        </div>
    </div>
@endsection
    