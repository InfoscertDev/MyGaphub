@extends('layouts.admin')

@section('content')

    <div class="wd-f my-5">
        <div class="gap-center">
            <h2 class="display-4">GAPhub Admin Dashboard</h2>
        </div>
    </div>

@endsection